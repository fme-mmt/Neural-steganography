// https://observablehq.com/d/26101b1a6816711f@182
export default function define(runtime, observer) {
  const main = runtime.module();
  main.variable(observer()).define(["md"], function(md){return(
md`# Neural Steganography`
)});
  main.variable(observer()).define(["md"], function(md){return(
md`**steganography **| stɛɡəˈnɒɡrəfɪ |
_noun [mass noun]_

the practice of concealing messages or information within other non-secret text or data.
ORIGIN
late 16th century: modern Latin _steganographia_, from Greek _steganos_ ‘covered’+ -_graphy_.`
)});
  main.variable(observer()).define(["md"], function(md){return(
md`## History of steganography
> The first recorded uses of steganography can be traced back to 440 BC when Herodotus mentions two examples in his Histories. Histiaeus sent a message to his vassal, Aristagoras, by shaving the head of his most trusted servant, "marking" the message onto his scalp, then sending him on his way once his hair had regrown, with the instruction, "When thou art come to Miletus, bid Aristagoras shave thy head, and look thereon." 

(from [Wikipedia](https://en.wikipedia.org/wiki/Steganography#Techniques))
`
)});
  main.variable(observer()).define(["md"], function(md){return(
md`More history:
> During and after World War II, espionage agents used photographically-produced microdots to send information back and forth. Microdots were typically minute (less than the size of the period produced by a typewriter). World War II microdots were embedded in the paper and covered with an adhesive, such as collodion that was reflective and so was detectable by viewing against glancing light. Alternative techniques included inserting microdots into slits cut into the edge of postcards.

![A microdot camera](https://upload.wikimedia.org/wikipedia/commons/9/9a/Microdot_camera_markiv.jpg)

> Jeremiah Denton repeatedly blinked his eyes in Morse code during the 1966 televised press conference that he was forced into as an American prisoner-of-war by his North Vietnamese captors, spelling out "T-O-R-T-U-R-E". That confirmed for the first time to the US Naval Intelligence and other Americans that the North Vietnamese were torturing American prisoners-of-war`
)});
  main.variable(observer()).define(["md","text"], function(md,text){return(
md`### Null ciphers

A null cipher, also known as *concealment cipher*, is an ancient form of encryption where the plaintext is **mixed with a large amount of non-cipher material**. Today it is regarded as a simple form of steganography, which can be used to hide ciphertext

Here is an example implementation of a **null cipher**. Stringing together the first letter of every third word of the following covertext reveals "Wikipedia" as the hidden message:

> It's important **w**e allow anyone **i**nterested in gaining **k**nowledge access to **i**nformation which is **p**ublished freely. There **e**xists a website **d**evoted to this **i**dea, and you **a**re on it!

A similar technique is to hide entire words, such as in this seemingly innocent message written by a prison inmate but deciphered by the FBI:

> ${text}


Taking only every fifth word, one can reconstruct the hidden text which recommends a "hit" on someone
`
)});
  main.variable(observer()).define(["text"], function(text)
{ 
 let toks = text.split(' ');
 const skip = 5;
 var sel = []
 for (var i=skip-1; i<toks.length; i+=skip)
   sel.push(toks[i]);

return sel; // .join(' ')
}
);
  main.variable(observer()).define(["md"], function(md){return(
md`## In literature
Also from [wikipedia](https://en.wikipedia.org/wiki/Solitaire_(cipher)):
>The Solitaire cryptographic algorithm was designed by Bruce Schneier at the request of **Neal Stephenson for use by field agents in his novel _Cryptonomicon_**, enabling them to communicate securely without having to rely on electronics or having to carry incriminating tools,[1] It was designed to be a manual cryptosystem calculated with an ordinary deck of playing cards. In Cryptonomicon, this algorithm was originally called Pontifex to hide the fact that it involved playing cards.
>
> One of the motivations behind Solitaire's creation is that in totalitarian environments, a deck of cards is far more affordable (and less incriminating) than a personal computer with an array of cryptological utilities. However, as Schneier warns in the appendix of _Cryptonomicon_, just about everyone with an interest in cryptanalysis will know about this algorithm. Additionally, it was found to have a significant bias towards repeating characters (1/22.5 rather than 1/26), so it is considered insecure`
)});
  main.variable(observer()).define(["md"], function(md){return(
md`The Wikipedia article concludes (emphasis mine):
> In general, it is difficult and time-consuming to produce covertexts that **seem natural** and would not raise suspicion. If **no key or actual encryption is involved**, the security of the message relies entirely on the **secrecy of the concealment method**. Null ciphers in modern times are used by prison inmates in an attempt to have their most suspicious messages pass inspection`
)});
  main.variable(observer()).define(["md"], function(md){return(
md`Image of a tree with a steganographically hidden image. The hidden image is revealed by **removing all but the two least significant bits of each color component and a subsequent normalization**. 

![original](https://upload.wikimedia.org/wikipedia/commons/a/a8/Steganography_original.png)
gives
![recovered](https://upload.wikimedia.org/wikipedia/commons/c/c3/Steganography_recovered.png)`
)});
  main.variable(observer()).define(["md"], function(md){return(
md`## Steganography in Streaming Media

Since the era of evolving network applications, steganography research has shifted from image steganography to steganography in streaming media such as Voice Over Internet Protocol (VoIP).

* In 2003, Giannoula et al. developed a data hiding technique leading to compressed forms of source video signals on a frame-by-frame basis.[17]

* In 2005, Dittmann et al. studied steganography and watermarking of multimedia contents such as VoIP.[18]

* In 2008, Yongfeng Huang and Shanyu Tang presented a novel approach to information hiding in low bit-rate VoIP speech stream, and theirs published work on steganography in [19] is the first ever effort to improve the codebook partition by using Graph theory along with Quantization Index Modulation in low bit-rate streaming media.

* In 2011 and 2012, Yongfeng Huang and Shanyu Tang devised new steganographic algorithms that use _codec parameters_ as cover object to realise real-time covert VoIP steganography. Their findings were published in IEEE Transactions on Information Forensics and Security.[20][21]`
)});
  main.variable(observer()).define(["md"], function(md){return(
md`## Classes of linguistic steganography methods

* **Edit-based**: The content of the cover text is selected by a human and *slightly modified* to encode information 

* **Generation-based**: An entire block of text is generated while *encoding the message reversibly* in the choice of tokens.

Traditionally, most practical stenography systems are *edit-based*. These methods only encode a **small amount of information** (for example, 2 bits per tweet), whereas generation-based systems can encode an **order of magnitude more information**.
`
)});
  main.variable(observer()).define(["md"], function(md){return(
md`
Given the **LM context**:
> Washington received his initial military training and command with the Virginia Regiment during the French and Indian War. He was later elected to the Virginia House of Burgesses and was named a delegate to the Continental Congress, where he was appointed Commanding General of the nation's Continental Army. Washington led American forces, allied with France, in the defeat of the British at Yorktown. Once victory for the United States was in hand in 1783, Washington resigned his commission.

and the **cover text**:
> He served as Admiral of the Sixth Army to train Continental troops in England in 1811 with the exception of his campaign against the French. After the French and

we can [decrypt it](https://steganography.live/decrypt).

For encryption  [use this](https://steganography.live) with **LM context** and **secret text**.

The implementation is in [github](https://github.com/harvardnlp/NeuralSteganography)
`
)});
  main.variable(observer()).define(function()
{ 
  return Math.PI;
}
);
  main.variable(observer()).define(["tex","md","repo"], function(tex,md,repo)
{let plm= tex`p_{\tiny\mathrm{LM}}`

 return md`# The paper

Given:
* A *Language Model* ${plm} shared by Alice and Bob
* A *secret message* ${tex`\mathbf{m}`}
* An *encryption function* ${tex`f`} depending on ${plm}

Gives *cover text* ${tex`y`}

![encryption](${repo}/raw/master/paper/encrypting.png)`
}
);
  main.variable(observer()).define(["md","tex","repo"], function(md,tex,repo){return(
md`## Arithmetic coding

Arithmetic coding is a data compression method designed specifically to code strings of elements with a known probability distribution.

In practice, it is often more efficient than Huffman coding because it does not require blocking.

In the figure below, each concentric circle represents the conditional distribution ${tex`p(y_t |y_{<t})`}.
The circle diagram spans ${tex`[0,1)`} from 0 at the top, clockwise around to 1.

![arithmetic encoding](${repo}/raw/master/paper/arithmetic-coding.png)`
)});
  main.variable(observer()).define(["md"], function(md){return(
md`## Suggested Tasks:

* Read the paper from Ziegler et al.
* Understand the probabilistic model GPT2
* Store a trained model for English for testing in a local machine
* Understand arithmetic coding
* Try to implement a solution for a language other than English (or a reduced model if needed)

## References:

* Z. M. Ziegler,  Yuntian Deng, A. M. Rush Neural Linguistic Steganography arXiv: 1909.01496v1
* Radford, Alec, et al. Language models are unsupervised multitask learners. OpenAI Blog 1.8 (2019).`
)});
  main.variable(observer("repo")).define("repo", function(){return(
"https://github.com/fme-mmt/Neural-steganography"
)});
  main.variable(observer("text")).define("text", function(){return(
"SALUDOS LOVED ONE SO TODAY I HEARD FROM UNCLE MOE OVER THE PHONE. HE TOLD ME THAT YOU AND ME GO THE SAME BIRTHDAY. HE SAYS YOUR TIME THERE TESTED YOUR STRENGTH SO STAY POSITIVE AT SUCH TIMES. I'M FOR ALL THAT CLEAN LIVING! METHAMPHETAMINES WAS MY DOWN FALL. THE PROGRAM I'M STARTING THE NINTH IS ONE I HEARD OF A COUPLE WEEKS BEFORE SEPTEMBER THROUGH MY COUNSELOR BARRIOS. BUT MY MEDICAL INSURANCE COVERAGE DENIES THEY COVER IT. I'M USING MY TIME TO CHECK AND IF THE INSURANCE AGENT DENIES STILL MY COVERAGE I'M GETTING TOGETHER PAPERWORK SAYING I TESTED FOR THIS TREATMENT REQUIRED ON THE CHILD CUSTODY. THE NINTH WILL MEAN I HAVE TESTED MY DETERMINATION TO CHANGE. ON THE NEXT FREE WEEKEND THE KIDS ARE COMING, BUT FIRST I GOTTA SHOW CAROLINA I'M STAYING OUT OF TROUBLE WAITING TO GET MYSELF ADMITTED ON THE PROGRAM. THE SUPPORTING PAPERWORK THAT THE FAMILY COURTS GOT WILL ALSO PROVE THERE'S NO REASON NEITHER FOR A WITNESS ON MY CHILDREN'S VISITS. OF COURSE MY BRO HAS HIS MIND MADE UP OF RECENT THAT ALL THIS DRUG USAGE DON'T CONCERN OUR VISITS. I THINK THAT MY KIDS FEEL I NEED THEIR LOVE IF I'M GONNA BE COOL. GUILTY FEELINGS RISE ON ACCOUNT OF THE MISTAKES I COULD WRITEUP. FOR DAYS I'M HERE. HE GOT A GOOD HEART. SHOULD YOU BE HAVING PROBLEMS BE ASSURED THAT WHEN YOU HIT THE STREETS WE'LL BE CONSIDERING YOU"
)});
  return main;
}
